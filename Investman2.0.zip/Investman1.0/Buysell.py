# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""





# Use query to import values






    





    

# Database -> Query is correct but does not return an error but does not effectively change the
# records

# Windows destroyen
    
    
    
    
    
    
    

    


    
    
    

    


