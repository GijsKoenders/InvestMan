# -*- coding: utf-8 -*-
"""
Created on Thu Jan 10 17:57:00 2019

@author: u303699
"""

def dbconnect():
    
    import MySQLdb as SQL # Import SQL package
    
    # Define connection to MySql database
    global conn
    conn = SQL.connect ("sql7.freemysqlhosting.net", "sql7273333",password = "mnInPtemi4", db ="sql7273333") 
    # Define cursor to be able to communicate to database
    global c
    c = conn.cursor ()
    
    
def hashing (pw): # Defining a function for hashing the passwords 
    import hashlib
    pw = pw.encode ('utf-8')
    hash1 = hashlib.md5 (pw)
    return hash1

def getdbvalues (username):
    "Get trading info from database"
    import numpy as np
    dbconnect() # Get connection to the database
    # table name = investman_login
    username = username
    query = """ SELECT balance, Bitcoin, Ripple, Ethereum, Substratum 
    FROM investman_login
    WHERE username = %s"""
    c.execute (query, (username, )) 
    data = c.fetchall () #This command fetches the data from the database in a tuple
    
    
    data = np.array (data[0]) # Converting the tuple to an numpy array
    
    return data

def insertdbvalues (username, newbalance, newbal, name):
    "Return new balances to database"
    dbconnect ()
    query = """INSERT INTO investman_login (balance, %s 
            VALUES (%s, %s)
            WHERE username = %s"""
    c.execute (query, (name, newbalance, newbal, username))


    


    







