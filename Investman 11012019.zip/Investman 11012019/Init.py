# -*- coding: utf-8 -*-
"""
Created on Thu Jan 10 17:26:05 2019

@author: u303699
"""

import Buysell

def init (root, username, geo = "600x600"):
    "Initialize frame and standard features"
    root.geometry (geo)
    Dropdown (root, username) 
    Toolbar (root, username)
    Statusbar (root)

def Dropdown (root, username):
    "Creating a single dropdown menu for Investman"
    
    menu = Menu (root) # Menu function activation
    root.config (menu = menu) # Prepare our menu
    
    subMenu = Menu (menu) # Menu in a menu
    menu.add_cascade (label = "My account", menu = subMenu) # Obviously the label stands for the label of the menu, and the menu
    # argument creates a new dropdown
    subMenu.add_command (label = "Account details", command =lambda: Accountdetails (username))
    subMenu.add_separator ()
    
    # Adding another dropdown menu
    subMenu2 = Menu (menu)
    menu.add_cascade (label = "Portfolio", menu = subMenu2)
    subMenu2.add_command (label = "Crypto")
    subMenu2.add_command (label = "Stocks")
    
def Toolbar (root, username):
    "Creating a toolbar"
    toolbar = Frame (root)
    Logoutbut = Button (toolbar, text = "Log out", bg = "red", fg= "white", command = lambda: Messages.MessageboxAuto (root)) 
    # Here an example how to give parameters to a function within a command
    Logoutbut.pack (side = RIGHT, padx = 4, pady = 3) # Displaying our button on the screen, by using padx and pady it is possible to leave space between
  # elements
    Ledgerbut = Button (toolbar, text = "Ledger", bg = "yellow", fg= "white")
    Ledgerbut.pack (side = RIGHT, padx = 4, pady = 3)
    
    # Importing the canvas
    Canvasbut = Button (toolbar, text = "Graphics", bg = "blue", fg= "white", command =InvestCanvas)
    Canvasbut.pack (side = RIGHT, padx = 4, pady = 3)
    
    Investbut = Button (toolbar, text = "Invest!", bg = "green", fg= "white", command = lambda: Invest (username))
    Investbut.pack (side = RIGHT, padx = 4, pady = 3)
    
    toolbar.pack (side = TOP, fill = X)
    
def Statusbar (root):
    "Creation of the statusbar in the bottom of the window"
    status = Label (root, text = "Property of Selim Berntsen", bd = 1, relief = SUNKEN, anchor = W)
    status.pack (side= BOTTOM, fill = X)
    
Startpage ("Muppets")