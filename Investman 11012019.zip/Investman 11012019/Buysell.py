# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


# Use query to import values

def Invest (username):
    
    root = Tk ()
    
    init (root, username)
    #getdbvalues (username) # Importing values into the page still has to happen
    
    #username, balance = getdbvalues (username)
    # balance = str(balance)

    text1 = Label (root, text = "So you think you are ready to invest?", font = "Helvetica") # Creating a text object
    # Maybe include a show me what you got image
    text2 = Label (root, text = "Choose from the panel where you want to invest in", font = "Helvetica")
    balancewindow = Label (root, text = "Your balance is $" ,font = "Helvetica") 
    # How to put balance in text parameter + str(balance)
    
    def choosebut (name, col, com):
        button = Button (root, text = name, bg = col, fg = "white", command = com)
        button.pack (side = BOTTOM)
        
    choosebut ("Bitcoin", "blue", Bitwindow)
    choosebut ("Ripple", "red", Ripwindow)
    choosebut ("Ethereum", "green", Ethwindow)
    choosebut ("Substratum", "purple", Ethwindow)

    text1.pack (side = TOP)
    text2.pack (side = BOTTOM)
    balancewindow.pack (side = LEFT)

    root.mainloop ()
    
def Bitwindow ():
    
    root = Tk ()
    
    root.mainloop ()
    
def Ripwindow ():
    
    root = Tk ()
    
    root.mainloop () 
    
def Ethwindow ():
    
    root = Tk ()
    
    root.mainloop ()
    
def Subswindow ():
    
    root = Tk ()
    
    root.mainloop ()
    
    
    
        




    



