import database
import Messages

def Loginscreen ():
    "Shows login screen in GUI"
    
    root = Tk()
    root.title("Login")
    root.geometry ("300x100")

    # Create this method before you create the entry
    def return_entry(root):
        """Gets and prints the content of the entry"""
        username = entry_username.get()
        pw = entry_password.get ()
        loginback (username, pw, root)
        
    # Create all messages and entries needed on the page    
    Message = Label (root, text = "Please enter your login details below", font='Verdana 10')
    LabelUsername = Label (root, text = "Please enter username")
    LabelPassword = Label (root, text = "Please enter your password")
    entry_username = Entry (root) # An entry is the same as the user input, a field where the user can input something
    entry_password = Entry (root, show = "*")

    # Place all the messages in a grid, by using rows and columns it is possible to position labels, entries and buttons
    Message.grid (row = 0, columnspan = 4, sticky = W)
    LabelUsername.grid (row = 1, sticky = W)
    LabelPassword.grid (row = 2, sticky = W) 
    entry_username.grid (row = 1, column = 1) 
    entry_password.grid (row = 2, column = 1)

    # Adding a button to actually log in
    Loginbut = Button (root, text = "Log me in!", command = lambda: return_entry (root) )
    Loginbut.grid (row = 3, sticky = W)
        
    root.mainloop ()
    
    
def loginback (username, pw, root):
    " Login function"
    
    dbconnect ()
    
   # Extracting the usernames from the database
    query = "SELECT username FROM investman_login "
    c.execute(query)
    u_result = c.fetchall() 
    username_result = [list(i) for i in u_result] # Make a list of lists
    username_list = [item for sublist in username_result for item in sublist] # Flatten list
        

    #Extracting the passwords from the database
    query = "SELECT passwordu FROM investman_login"
    c.execute(query)
    p_result = c.fetchall() 
    password_result = [list(i) for i in p_result] # Make a list of lists
    password_list = [item for sublist in password_result for item in sublist]  # flatten list
    
    pw = hashing (pw)  
    pw = pw.hexdigest()
    zipped = zip(username_list, password_list) # Make a zipped file of usernames and passwords
    
    combination = False
    
    for name, pas in zipped: # Check if inputs are in the zipped list of usernames and passwords
        user = name
        word = pas
        if username == user and pw == word:
            combination = True
            root.destroy ()
            Startpage (username) # If username and password are correct -> open the startpage
            break

            
    if combination == False: # Give following output when combination of username and password is correct
            MessageManualWarning ( "False login", "Username and/or password is incorrect")
