# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""




# Use query to import values

def Invest (username):
    
    root = Tk ()
    
    init (root, username)
    #getdbvalues (username) # Importing values into the page still has to happen
    
    balance = getdbvalues (username)
    bitbalance = getdbvalues (username)
    ripbalance = getdbvalues (username)
    ethbalance = getdbvalues (username)
    subsbalance = getdbvalues (username)
    balance = str(balance)
    
    # print (balance)

    text1 = Label (root, text = "So you think you are ready to invest?", font = "Helvetica") # Creating a text object
    # Maybe include a show me what you got image
    text2 = Label (root, text = "Choose from the panel where you want to invest in", font = "Helvetica")
    balancewindow = Label (root, text = "Your balance is $"  ,font = "Helvetica")
    amountwindow = Label (root, text = balance ,font = "Helvetica")
    # How to put balance in text parameter + str(balance)
    
    def choosebut (name, col, com):
        button = Button (root, text = name, bg = col, fg = "white", command = lambda: com)
        button.pack(side = BOTTOM)
        
        
    choosebut ("Bitcoin", "blue", cryptowindow (username, bitbalance, "Bitcoin", root))
    choosebut ("Ripple", "red", cryptowindow (username, ripbalance, "Ripple", root))
    choosebut ("Ethereum", "green", cryptowindow (username, ethbalance, "Ethereum", root))
    choosebut ("Substratum", "purple", cryptowindow (username, subsbalance, "Substratum", root))

    text1.pack (side = TOP)
    text2.pack (side = BOTTOM)
    balancewindow.pack (side = LEFT)
    amountwindow.pack (side = LEFT)

    root.mainloop ()
    
def cryptowindow (username, fetch, name, root):
    
    child = Toplevel (root)
    
    init (root, username)
    
    #fetch = getdbvalues (username)
    fetch = str(fetch)
    
    amount1 = Label (root, text = "Your current balance in" + name + "is", font = "Helvetica") 
    amount2 = Label (root, text = fetch, font = "Helvetica")
    
    amount1.pack (side = LEFT)
    amount2.pack (side = LEFT)
    
    

    

    
Invest ("Muppets")
    
 
    
    
        




    



