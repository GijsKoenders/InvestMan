from tkinter import *

def signupscreen ():
    "Setting up the signup screen"
    
    root = Tk()
    root.title("SignUp")
    root.geometry ("450x200")   

    # Create this method before you create the entry
    def return_entry(root):
        """Gets and prints the content of the entry"""
        username = entry_username.get()
        pw = entry_password.get ()
        signupback (username, pw, root)
    
    # Create all messages and entries needed on the page
    Message = Label (root, text = """Welcome once again to Investman!
    Please follow the instructions below to create your account.\n""", font='Verdana 10')
    LabelUsername = Label (root, text = "Pick your preferred username:")
    LabelPassword = Label (root, text = "Pick your preferred password:")
    entry_username = Entry (root) # An entry is the same as the user input, a field where the user can input something
    entry_password = Entry (root, show = "*") 
    InfoLabel = Label (root, text = """Attention! 
    Your password needs at least one lowercase, one uppercase and one number!""", fg = "red")
    
    # Place all the messages in a grid, by using rows and columns it is possible to position labels, entries and buttons
    Message.grid (row = 1, columnspan = 4, sticky = W)
    LabelUsername.grid (row = 4, sticky = W)
    LabelPassword.grid (row = 6, sticky= W) 
    entry_username.grid (row = 4, column = 1, sticky = W) 
    entry_password.grid (row = 6, column = 1, sticky = W) 
    InfoLabel.grid (row = 8, columnspan = 4, sticky = W)
    
    # Adding a button to confirm data
    Confirmbut = Button (root, text = "Confirm", command = lambda: return_entry (root))
    Confirmbut.grid (row = 7, columnspan = 2, sticky = E)

    root.mainloop ()


def signupback (username, pw, root):
    "Signing up to Investman"
    
    dbconnect () # Connect to online database

    # Write a SQL command and store it as a string. In this command we ask to store the username and the password in the database
    my_string = "INSERT INTO investman_login (username, passwordu, balance)" "VALUES (%s, %s, 100000)" # The user will get 100000 EU assigned to there account

    # Create username and password from entries
            
    while True: # This while loop is used to run the loop as long as the code gives no error
        try:    
    
            from string import punctuation, digits

            digitpw = False
            lowercase = False
            uppercase = False

            for char in pw:
                if char in digits:
                    digitpw = True
                elif char.islower():
                    lowercase = True
                elif char.isupper():
                    uppercase = True
                elif char == " ":
                    break
                    
            if digitpw == False or lowercase == False or uppercase == False:
                MessageManualWarning ("Error", "Your password does not meet the given requirements")
                break
                
            else:
                pw = hashing (pw)  
                pw = pw.hexdigest()
                user_pass = (username, pw)

            # Execute SQL command by passing in the string and the user variables (username and password)
            c.execute (my_string, user_pass)

            #Complete actions
            conn.commit ()
            conn.close ()
            root.destroy ()
            Loginscreen ()
        
        except:
            MessageManualWarning ("Error", "We have encountered an error, you most likely chose a username that is already in use.")
            break
        break



