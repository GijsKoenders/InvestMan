# Initialize Investman

def init (root, username, geo = "500x400"):
    "Initialize frame and standard features"
    root.geometry (geo)
    Dropdown (root, username) 
#    Toolbar (root, username)
    Statusbar (root)

def Dropdown (root, username):
    "Creating a single dropdown menu for Investman"
    
    # Creating a menu and activating function possiblities
    menu = Menu (root)
    root.config (menu = menu)
    
    # Argument creating multiple menus in the menubar
    subMenu = Menu (menu)
    menu.add_cascade (label = "Settings", menu = subMenu) # Obviously the label stands for the label of the menu, and the menu
    subMenu.add_command (label = "Account details", command = lambda: Accountdetails (username))
    subMenu.add_command (label = "Disclaimer", command = lambda: Disclaimer())
    subMenu.add_command (label = "Logout", command = lambda: Messages.MessageboxAuto (root))
    subMenu.add_command (label = "Exit", command = root.destroy)
    
    subMenu2 = Menu (menu)
    menu.add_cascade (label = "Cryptocurrency", menu = subMenu2)
    subMenu2.add_command (label = "Investing overview", command = lambda: Invest (username))
    subMenu2.add_command (label = "Bitcoin", command = lambda: cryptowindow (username, bitbalance, "Bitcoin", root))
    subMenu2.add_command (label = "Ethereum", command = lambda: cryptowindow (username, ethbalance, "Ethereum", root))
    subMenu2.add_command (label = "Substratum", command = lambda: cryptowindow (username, subsbalance, "Substratum", root))
    subMenu2.add_command (label = "Ripple", command = lambda: cryptowindow (username, ripbalance, "Ripple", root))
    
    subMenu3 = Menu (menu)
    menu.add_cascade (label = "Highscores", menu = subMenu3)
    
"""# We wanted to add an easy access menu toolbar at the bottom, plus, it looks good :)    
def Toolbar (root, username):
    "Creating a toolbar"
    
    toolbar = Frame (root)
    
    #Creating three easy access buttons on the bottom of the page
    Investbut = Button (toolbar, text = "Invest!", bg = "green", fg= "white", command = lambda: Invest (username))
    Investbut.pack (side = LEFT, padx = 4, pady = 3) # Displaying our button on the screen, by using padx and pady it is possible to leave space between
    
    Ledgerbut = Button (toolbar, text = "Highscores", bg = "blue", fg= "white")
    Ledgerbut.pack (side = LEFT, padx = 4, pady = 3)
    
    Logoutbut = Button (toolbar, text = "Log out", bg = "red", fg= "white", command = lambda: Messages.MessageboxAuto (root)) 
    Logoutbut.pack (side = LEFT, padx = 4, pady = 3) 
   
    toolbar.pack (side = BOTTOM, fill = X)"""
    
def Statusbar (root):
    "Creation of the statusbar in the bottom of the window"
    status = Label (root, text = "Property of Selim Berntsen, Julian van Bree and Gijs Koenders", bd = 1, relief = SUNKEN, anchor = W)
    status.pack (side = BOTTOM, fill = X)