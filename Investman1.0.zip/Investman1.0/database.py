# -*- coding: utf-8 -*-
"""
Created on Thu Jan 10 17:57:00 2019

@author: u303699
"""

def dbconnect():
    
    import MySQLdb as SQL # Import SQL package
    
    # Define connection to MySql database
    conn = SQL.connect (host = "web0082.zxcs.nl", user = "u37554p38733_investmandb",
                           password = "Password123", db ="u37554p38733_investmandb") 
    # Define cursor to be able to communicate to database
    c = conn.cursor ()
    return conn, c
    
    
def hashing (pw): # Defining a function for hashing the passwords 
    import hashlib
    pw = pw.encode ('utf-8')
    hash1 = hashlib.md5 (pw)
    return hash1

def getdbvalues (username):
    "Get trading info from database"
    import numpy as np
    dbconnect() # Get connection to the database
    # table name = investman_login
    username = username
    query = """ SELECT balance, Bitcoin, Ripple, Ethereum, Substratum 
    FROM investman_login
    WHERE username = %s"""
    c.execute (query, (username, )) 
    data = c.fetchall () #This command fetches the data from the database in a tuple
    
    
    data = np.array (data[0]) # Converting the tuple to an numpy array
    
    return data
    
    conn.commit ()
    conn.close ()

def insertdbvalues (username, newbalance, newbal, name):
    "Return new balances to database"
    dbconnect ()
    query = """UPDATE investman_login 
    SET balance = %s,{0}= %s 
    WHERE username = %s;""".format (name) # Using the format button in order to avoid SQL interpreting quation marks
    c.execute (query, (newbalance, newbal, username))
    
    conn.commit
    conn.close
    
#import MySQLdb as SQL
    
#conn = SQL.connect ("sql7.freemysqlhosting.net", "sql7273333",password = "mnInPtemi4", db ="sql7273333")
#c = conn.cursor ()
#query = """UPDATE investman_login 
#    SET balance = 120000.00, bitcoin = 5.93 
#    WHERE username = 'Frederik';"""
#c.execute (query)    

    





    
    


    

    






