# -*- coding: utf-8 -*-
"""
Created on Thu Jan 17 14:28:04 2019

@author: gijsd
"""

import tkinter as tk
#import MySQLdb as SQL # http://www.phpmyadmin.co/ -> Online database server
from PIL import ImageTk,Image
import Messages
from Init import init
import Buysell


def Startframe ():
    
    root = tk.Tk ()
    root.title("Investman")
    root.geometry ("450x200")
    
    textobject = tk.Label(root, text = "Welcome to Investman!", font='Verdana 18 bold') # Creating a text object
    textobject.pack ()
    
    textobject1 = tk.Label(root, text = """
    Investman is a small game created for the Basic Programming course at
    Tilburg University. In Investman you can invest in cryptocurrency updated 
    in real-time and try to beat your friends by investing wisely and beating 
    \tthem in the highscores! Thank you for playing our game!                     
    """)
    textobject1.pack ()
    
    textobject2 = tk.Label(root, text = "Please select one of the following options to continue :\n") # Creating a text object
    textobject2.pack ()

    Startframe = tk.Frame (root, width = 300, height = 200) # Create start frame
    Startframe.pack (side = "top") # Please it in the top corner and tell where to place it

    Signupbutton = tk.Button (Startframe, text = "No account yet? Sign up here!", fg = "blue", command = signupscreen) # Creating buttons
    Loginbutton = tk.Button (Startframe, text = "Sign me in!", fg = "green", command = Loginscreen) # fg = font colour, bg = background colour
    Quitbutton = tk.Button (Startframe, text = "Get me out of here!", fg = "red", command = root.destroy)

    Quitbutton.pack (side = "right")
    Signupbutton.pack (side = "right")
    Loginbutton.pack (side = "right")
    
    root.mainloop ()


def Startpage (username):
    "Layout startpage"
    
    root = tk.Tk()
    root.title ("Investman")
    init (root, username)
    
    # img = PhotoImage(file = r"C:\Users\Selim Berntsen\Documents\Premaster_DSBG_CSAI\Basic Programming\Group assignment\50moneyphone.png")  
    # Does not work yet:
    # welcomepic = PhotoImage (file = 'C:/Users/Selim Berntsen/Documents/Premaster_DSBG_CSAI/Basic Programming/Group assignment/money.png')
    
    Titlemessage = tk.Label (root, text = "Welcome " + username + """ once again to Investman!
    Are you ready to InvestMan??.\n""", font = "Verdana 14 bold")
    Titlemessage.pack ()
    # imgLabel = Label (root, image = img)
    # imgLabel.pack (side = BOTTOM)
    root.mainloop ()
    
    
def Disclaimer ():
    
    root = Tk ()
    root.title("Disclaimer")
    root.geometry ("650x300")
    
    textobject = tk.Label(root, text = "The man that invests", font='Verdana 18 bold')
    textobject.pack()
    
    textobject1 = tk.Label(root, text = "InvestMan is the game in which man invests", font='Verdana 12 bold')
    textobject1.pack()
    
    textobject2 = tk.Label(root, text = """
    *The InvestMan brand is intellectual property of Gijs Koenders, Julian van Bree, and Selim Berntsen. 
    *The Lawyers of the InvestMan brand pointed out to disclaim the following: 
    *The InvestMan brand does not exclude any religious, gender, or other potential minority groups 
    that may be harmed by the intellectual property. 
    *The 'Man' in the InvestMan brand might be misleading, as the 'Man' stands for Metropolitan Area Network (MAN). 
    *This means that the full name of the InvestMan brand is: 'Invest Metropolitan Area Network brand. 
    *The subtitle: The man that invests = The Metropolitan Area Network that invests. 
    *The description: InvestMan is the game in which man invests = Invest Metropolitan 
    Area Network is the game in which Metropolitan Area Network invests                    
    """)
    textobject2.pack()

    Quitbutton = tk.Button (root, text = "This does not make any sense!", command = root.destroy)
    Quitbutton.pack()
    
    root.mainloop ()
    

def Accountdetails (username):
    "Shows Account details in GUI"
    
    # Ofcource the dropdownmenu should be included as well, maybe as a class or maybe just as a function
    root = tk.Tk()
    
    init (root, username)
    
#     # Initialize interface features
#     Dropdown (root, username) 
#     Toolbar (root)
#     Statusbar (root)

    # Page content
    Contentframe = tk.Frame (root)
    Contentframe.pack (side = "top")
    LabelUsername = tk.Label (Contentframe, text = "username")
    LabelPassword = tk.Label (Contentframe, text = "password")
    Username = tk.Label (Contentframe, text = username)
    Password =tk.Label(Contentframe, text = "xxxxxx")
    changepw = tk.Button(Contentframe, text = "Change my password", fg = "red")
    LabelBalance = tk.Label (Contentframe, text = "Your balance ")
    BalanceAmount = tk.Label (Contentframe, text = "$" + "100")
    
    LabelUsername.grid (row = 0, sticky = "w") # With the sticky argument it is possible to stick something to eitherside of the column 
    # West (W) means left allgined and East (E) means right alligned)
    LabelPassword.grid (row = 1, sticky = "w")
    LabelBalance.grid (row = 2, sticky = "w")
    Username.grid (row = 0, column = 2) 
    Password.grid (row = 1, column = 2) # By using rows and columns it is possible to position labels, entries and buttons
    BalanceAmount.grid  (row = 2, column = 2)   
    changepw.grid (row = 3, columnspan = 3) # columnspann is the with of the widget

    root.mainloop ()
    


def signupscreen ():
    "Setting up the signup screen"
    
    root = Tk()
    

    # Create this method before you create the entry
    def return_entry(root):
        """Gets and prints the content of the entry"""
        username = entry_username.get()
        pw = entry_password.get ()
        signupback (username, pw, root)
        
    root.geometry ("200x300")    
    Message = Label (root, text = """We would like to welcome you into the world of Investman.
                                     Before we start you will be needing a username and a password.
                                     See you in a bit! """, fg = "green")
    Message.config (font = ("Verdana", 16)) # Configure font type
    
    LabelUsername = Label (root, text = "Enter the username of your choosing")
    LabelPassword = Label (root, text = "Please fill in your password")
    entry_username = Entry (root) # An entry is the same as the user input, a field where the user can input something
    entry_password = Entry (root, show = "*") 
    
    Message.grid (row = 1, sticky = "w") # Place the welcome message into the grid
    
    LabelUsername.grid (row = 4, sticky = "w") # With the sticky argument it is possible to stick something to eitherside of the column 
    # West (W) means left allgined and East (E) means right alligned)
    LabelPassword.grid (row = 6, sticky= "w") 
    entry_username.grid (row = 4, column = 1, sticky = "w") 
    entry_password.grid (row = 6, column = 1, sticky = "w") # By using rows and columns it is possible to position labels, entries and buttons

    # Adding a button to confirm data
    Confirmbut = Button (root, text = "Confirm", command = lambda: return_entry (root))
    Confirmbut.grid (row = 7, columnspan = 2, sticky = "w")

    # Connect the entry with the return button
 
    
    root.mainloop ()


def signupback (username, pw, root):
    "Signing up to Investman"
    
    conn, c = dbconnect () # Connect to online database

    # Write a SQL command and store it as a string. In this command we ask to store the username and the password in the database
    my_string = "INSERT INTO investman_login (username, password, balance)" "VALUES (%s, %s, 100000)" # The user will get 100000 EU assigned to there account

    # Create username and password from entries
            
    while True: # This while loop is used to run the loop as long as the code gives no error
        try:    
    
            from string import punctuation, digits

            digitpw = False
            lowercase = False
            uppercase = False

            for char in pw:
                if char in digits:
                    digitpw = True
                elif char.islower():
                    lowercase = True
                elif char.isupper():
                    uppercase = True
                elif char == " ":
                    break
                    
            if digitpw == False or lowercase == False or uppercase == False:
                MessageManualWarning ("Error", "Your password does not meet the given requirements")
                break
                
            else:
                pw = hashing (pw)  
                pw = pw.hexdigest()
                user_pass = (username, pw)

            # Execute SQL command by passing in the string and the user variables (username and password)
            c.execute (my_string, user_pass)

            #Complete actions
            conn.commit ()
            conn.close ()
            root.destroy ()
            Loginscreen ()
        
        except Exception as error:
            print ("error " + repr(error))
            MessageManualWarning ("Error", "We have entouraged an error, you possibly used an username that is already in use")
            break
        break
    
def Loginscreen ():
    "Shows login screen in GUI"
    
    root = tk.Tk()

    # Create this method before you create the entry
    def return_entry(root):
        """Gets and prints the content of the entry"""
        username = entry_username.get()
        pw = entry_password.get ()
        loginback (username, pw, root)
        
        
    LabelUsername = tk.Label (root, text = "Please enter username")
    LabelPassword = tk.Label (root, text = "Please enter your password")
    entry_username = tk.Entry (root) # An entry is the same as the user input, a field where the user can input something
    entry_password = tk.Entry (root, show = "*")


    LabelUsername.grid (row = 0, sticky = "w") # With the sticky argument it is possible to stick something to eitherside of the column 
    # West (W) means left allgined and East (E) means right alligned)
    LabelPassword.grid (row = 1, sticky = "w") 
    entry_username.grid (row = 0, column = 1) 
    entry_password.grid (row = 1, column = 1) # By using rows and columns it is possible to position labels, entries and buttons

    # Adding a button to actually log in
    Loginbut = tk.Button (root, text = "Go!", command = lambda: return_entry (root) )
    Loginbut.grid (row = 2, sticky = "w")
    
    # Adding a checkbox to ask if users want to stay logged in
    check = tk.Checkbutton (root, text = "Keep me logged in")
    check.grid (row = 2, column = 1) # columnspann is the with of the widget

    # Connect the entry with the return button
 
    
    root.mainloop ()
    
def loginback (username, pw, root):
    " Login function"
    
    conn, c = dbconnect ()
    
   # Extracting the usernames from the database
    query = "SELECT username FROM investman_login "
    c.execute(query)
    u_result = c.fetchall() 
    username_result = [list(i) for i in u_result] # Make a list of lists
    username_list = [item for sublist in username_result for item in sublist] # Flatten list
        

    #Extracting the passwords from the database
    query = "SELECT password FROM investman_login"
    c.execute(query)
    p_result = c.fetchall() 
    password_result = [list(i) for i in p_result] # Make a list of lists
    password_list = [item for sublist in password_result for item in sublist]  # flatten list
    
    pw = hashing (pw)  
    pw = pw.hexdigest()
    zipped = zip(username_list, password_list) # Make a zipped file of usernames and passwords
    
    combination = False
    
    for name, pas in zipped: # Check if inputs are in the zipped list of usernames and passwords
        user = name
        word = pas
        if username == user and pw == word:
            combination = True
            root.destroy ()
            Startpage (username) # If username and password are correct -> open the startpage
            break

            
    if combination == False: # Give following output when combination of username and password is correct
            MessageManualWarning ( "False login", "Username and/or password is incorrect")
            
Startframe ()