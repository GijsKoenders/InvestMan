# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""


import webscraper as ws
import database


# Use query to import values

def Invest (username):
        
    root = Tk ()
    
    init (root, username)
    #getdbvalues (username) # Importing values into the page still has to happen
    
    data = getdbvalues (username) # Retrieving the user data (balance information)
    
    balance = data [0]
    bitbalance = data [1]
    ripbalance = data [2]
    ethbalance = data [3]
    subsbalance = data [4] 
    
    prices = ws.prices()
    bitcoin_price = round(float(prices[0]),4)
    ethereum_price = round(float(prices[1]), 4) 
    ripple_price = round(float(prices[2]), 4)
    substratum_price = round(float(prices[3]), 4)
    
    profits = ((balance - 100000)/100000) * 100    
    profits = str(profits)
    
    
    # print (balance)

    text1 = Label (root, text = "So you think you are ready to invest?", font = "Helvetica") # Creating a text object
    # Maybe include a show me what you got image
    text2 = Label (root, text = "Choose from the panel where you want to invest in", font = "Helvetica")
    balancewindow = Label (root, text = "Your balance is $"  ,font = "Helvetica")
    amountwindow = Label (root, text = balance ,font = "Helvetica")
    # How to put balance in text parameter + str(balance)
    profitswindow = Label (root, text = "Profits: " + profits + "%" ,font = "Helvetica")
    
    def choosebut (name, col, com):
        button = Button (root, text = name, bg = col, fg = "white", command = com)
        button.pack(side = BOTTOM)    
        
    choosebut ("Bitcoin", "blue", lambda: cryptowindow (username, bitbalance, bitcoin_price, "Bitcoin"))
    choosebut ("Ripple", "red", lambda: cryptowindow (username, ripbalance, ripple_price, "Ripple"))
    choosebut ("Ethereum", "green", lambda: cryptowindow (username, ethbalance, ethereum_price, "Ethereum"))
    choosebut ("Substratum", "purple", lambda: cryptowindow (username, subsbalance, substratum_price, "Substratum"))

    text1.pack (side = TOP)
    text2.pack (side = BOTTOM)
    balancewindow.pack (side = LEFT)
    amountwindow.pack (side = LEFT)
    profitswindow.pack (side = LEFT)
    
    
    root.mainloop ()
    
    return balance
    
def cryptowindow (username, bal, price, name):
    
    root = Tk ()
    
    init (root, username) # Initializing
    
    # price = str(price)
    
    amount1 = Label (root, text = "Your current balance in " + name + " is ", font = "Helvetica") 
    amount2 = Label (root, text = bal, font = "Helvetica")
    
    price1 = Label (root, text = "The current price of " + name + " in dollars is ", font = "Helvetica") 
    price2 = Label (root, text = price, font = "Helvetica")
    
    tradebut = Button (root, text = "Buy or sell " + name, font = "Arial", bg = "green", command = lambda: Trade (username, bal, price, name)) # Soon to become trade window 
    
    amount1.pack (side = LEFT)
    amount2.pack (side = LEFT)
    price1.pack ()
    price2.pack ()
    tradebut.pack (side = BOTTOM)
    
    root.mainloop ()
    
def Trade (username, bal, price, name):
    "Window to buy and sell stocks"
    
    root = Tk()
    
    def input_trade (choice):
        trade = float(TraderEntry.get ())
        Buyorsell (username, choice, bal, price, name, trade)
        
    # Page content
    Trader =Label(root, text = "Amount that man invests in (either buy or sell " + name)
    TraderEntry = Entry(root)
    BuyBut = Button (root, text = "Buy " + name, command =  lambda: input_trade ("buy")) 
    SellBut = Button (root, text = "Sell" + name, command = lambda: input_trade ("sell"))
    
    Trader.grid (row = 2, sticky = W)
    TraderEntry.grid (row = 2, column = 2) 
    BuyBut.grid (row = 4, column = 1) # By using rows and columns it is possible to position labels, entries and buttons
    SellBut.grid  (row = 4, column = 2)   

    root.mainloop ()

def Buyorsell (username, choice, bal, price, name, trade):
    """Gets and prints the content of the entry"""
        
    balance = Invest (username) # Getting the balance variable
        
    # What if float is false?? 
    if choice == "buy":
        if trade > balance:
            MessageManualWarning ("Balance error", "Isufficient funds")
        else: 
            BuyBackend (username, bal, price, trade, name)
            MessageManualInfo ("Confirmation", "Your trade has been confirmed")
    else:
        if trade > bal:
            MessageManualWarning ("Balance error", "Isufficient funds")
        else:
            SellBackend (username, bal, price, trade, name)
            MessageManualInfo ("Confirmation", "Your trade has been confirmed")
            
    
def BuyBackend (username, bal, price, trade, name):
    "Calculations are made and sellinginformation gets exported to the database" 
    
    # Trade calculations
    balance = Invest (username)
    newbalance = balance - trade
    investment = trade / price
    newbal = bal + investment
    
    print (newbalance)
    print (newbal)
    
    # Communicate information to database
    database.insertdbvalues (username, newbalance, newbal, name)
    
    Invest (username) # Return to the invest page
    
def SellBackend (username, bal, price, trade, name):
    "Calculations are made and selling information gets exported to the database"
    
    # Trade calculations
    balance = Invest (username)
    newbalance = balance + trade
    investment = trade * price
    newbal = bal - investment
    
    # Communicate information to database
    database.insertdbvalues (username, newbalance, newbal, name)
    
    Invest (username) # Return to the investpage




    





    

# Database -> Query is correct but does not return an error but does not effectively change the
# records

# Windows destroyen
    
    
    
    
    
    
    

    


    
    
    

    


