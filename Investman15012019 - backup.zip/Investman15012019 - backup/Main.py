# -*- coding: utf-8 -*-
"""
Created on Thu Jan 10 17:38:02 2019

@author: u303699
"""

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# This is the first page what is seen when the application is first started

# First a couple of packages have to be installed

import tkinter as tk
#import MySQLdb as SQL # http://www.phpmyadmin.co/ -> Online database server
#from PIL import ImageTk,Image
import Login 
import Signup
import database
import Init


LARGE_FONT = ("Verdana", 12)
MEDIUM_FONT = ("Verdana", 10)
SMALL_FONT = ("Verdana", 8)

class Investman (tk.Tk): #tkinter.Tk is a inheretance, so taken over from an import function or variable maybe
    
    def __init__(self, *args, **kwargs): # These things will always run when calling the class, self is object itself
    # *args > passing through any number of variables, ** kwargs  is passing in dictionaries if necessary
    
        tk.Tk.__init__(self, *args, **kwargs)
        base = tk.Frame (self)
        base.pack (side = "top", fill = "both", expand = True)
        base.grid_rowconfigure (0, weight =1)
        base.grid_columnconfigure (0, weight = 1)
        
        self.frames = {}
        
        for F in (Startframe, Loginscreen, signupscreen, Startframe):
            
            frame = F (base, self)
            
            self.frames  [F] = frame
            
            frame.grid (row = 0, column = 0, sticky = "nsew")
        
        self.show_frame(Startframe)
        
    def show_frame(self, cont): # Defining the show_frame method
        frame = self.frames [cont]
        frame.tkraise() 
        

class Startframe (tk.Frame):
    
    def __init__(self, parent, controller): # The parent is the main class
        tk.Frame.__init__(self, parent)
        textobject = tk.Label (self, text = "This is the Investman GUI", font = LARGE_FONT) # Creating a text object
        textobject.pack (side = "top")
        
        Signupbutton = tk.Button (self, text = "No account yet? Sign up here!", fg = "blue",
                                  font = MEDIUM_FONT, command = lambda: controller.show_frame (signupscreen)) # Creating buttons
        Loginbutton = tk.Button (self, text = "Sign in please!", fg = "green", 
                                 font = MEDIUM_FONT, command = lambda: controller.show_frame (Loginscreen)) # fg = font colour, bg = background colour
        Quitbutton = tk.Button (self, text = "Get out of here!", fg = "red",
                                font = MEDIUM_FONT, command = self.destroy )
        
        Signupbutton.pack (side = "right")
        Loginbutton.pack (side = "right")
        Quitbutton.pack (side = "right")
        
execution = Investman ()
execution.mainloop ()
        
class Startpage (tk.Frame, username):
    "Layout startpage"
    
    def __init__(self, parent, controller): # The parent is the main class
        tk.Frame.__init__(self, parent)
    
    init (self, username)
    
    # Page content
    # Assign variables
    # img = PhotoImage(file = r"C:\Users\Selim Berntsen\Documents\Premaster_DSBG_CSAI\Basic Programming\Group assignment\50moneyphone.png")  
    # Does not work yet:
    # welcomepic = PhotoImage (file = 'C:/Users/Selim Berntsen/Documents/Premaster_DSBG_CSAI/Basic Programming/Group assignment/money.png')
    
    # Make content
    WelcomeMessage = Label (root, text = "Welcome " + username + "! Ready to InvestMan?")
    WelcomeMessage.pack (side = TOP)
    WelcomeMessage.config (font = ("Verdana", 16)) # Configure font type
    # imgLabel = Label (root, image = img)
    # imgLabel.pack (side = BOTTOM)
    root.mainloop ()


            

    


    

    

 
    


    

    

            

            
            

            
            

